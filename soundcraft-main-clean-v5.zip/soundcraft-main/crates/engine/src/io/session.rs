use super::bundle::save_session_bundle;
#[cfg(test)]
use super::import::add_source;
use super::import::{MAX_IMPORT_SAMPLES, at_rate, relink_videos};
use super::{
    Arc, Engine, EngineError, OsStr, Path, PathBuf, Result, Session, SourceAudio, file_key, read_file, read_session_text, stored_path, write_session,
};

/// Save the session to `path` (a `.scraft` file). Audio that only exists in memory is written
/// as 32-bit float WAV into `Audio Files/` next to it. Returns how many audio files were written.
///
/// In the browser there are no folders: the session and all its audio go out as one bundle file
/// (`<name>.scraftz`, see [`session_bundle`]) through the host's delivery hook ([`set_deliver`]).
pub fn save_session(e: &mut Engine, path: &str) -> Result<usize> {
    if cfg!(target_arch = "wasm32") {
        return save_session_bundle(e, path);
    }
    let (fresh, written, p) = write_session(e.session(), path, false)?;
    // Keep the in-memory document in sync (paths, unsaved flags) without an undo step.
    *e.session_mut() = fresh;
    e.path = Some(p.to_string_lossy().into_owned());
    e.mark_clean();
    Ok(written)
}

/// Write a copy of the session (and any audio it needs) without touching the open document —
/// used for autosave / crash recovery. Audio already written for a source is reused.
pub fn save_copy(e: &Engine, path: &str) -> Result<usize> {
    write_session(e.session(), path, true).map(|(_, n, _)| n)
}

/// File › Save Session Copy In: a normal session folder that does not rename, retarget or
/// clean the session that stays open.
pub fn save_session_copy(e: &Engine, path: &str) -> Result<usize> {
    write_session(e.session(), path, false).map(|(_, n, _)| n)
}

/// Open a `.scraft` session and decode its audio files (missing files are reported, not fatal).
pub fn open_session(e: &mut Engine, path: impl AsRef<Path>) -> Result<Vec<String>> {
    let path = path.as_ref();
    open_session_linked(e, path, path)
}

/// [`open_session`], following the media paths in it as if they were stored in the session file
/// `links` (crash recovery: the session written beside the autosave, its paths from the original).
pub(crate) fn open_session_linked(e: &mut Engine, path: &Path, links: &Path) -> Result<Vec<String>> {
    let text = read_session_text(path)?;
    let mut s = Session::from_json(&text).map_err(|err| EngineError::Io(err.to_string()))?;
    let dir = path.parent().map(Path::to_path_buf).unwrap_or_default();
    let mut missing = Vec::new();
    let mut files = DecodedFiles::new();
    for src in &s.sources {
        let decoded =
            stored_path(&src.path, links).map_err(|why| format!("{}: {why}", src.path)).and_then(|p| decode_file(&mut files, &p, s.sample_rate.hz()));
        match decoded {
            Ok(audio) => s.pool.insert(src.id, audio),
            Err(err) => missing.push(err),
        }
    }
    missing.extend(relink_videos(&mut s, links));
    s.folder = Some(dir);
    e.replace_session(s);
    // Save writes back to `e.path`, which is text: a session at a name that isn't valid Unicode
    // opens as if never saved, rather than saving to a name with replacement characters.
    e.path = path.to_str().map(str::to_owned);
    for m in &missing {
        e.message(format!("missing media: {m}"));
    }
    Ok(missing)
}

/// Decode one source's audio file at the session rate.
pub(super) fn decode_source(bytes: &[u8], ext: Option<&str>, rate: u32) -> std::result::Result<Arc<SourceAudio>, String> {
    let (_, buf) = craft_audio::decode(bytes, ext).map_err(|err| err.to_string())?;
    let buf = at_rate(buf, rate, MAX_IMPORT_SAMPLES).map_err(|e| e.message("too large to load"))?;
    Ok(Arc::new(SourceAudio::new(buf)))
}

pub(crate) type DecodedFiles = std::collections::HashMap<PathBuf, std::result::Result<Arc<SourceAudio>, String>>;

/// The audio of the file at `p` at `rate`, decoded the first time it is asked for. The error
/// names the file.
/// A file named in a session is hostile input too: a path that leaves the read root is not read.
pub(crate) fn decode_file(files: &mut DecodedFiles, p: &Path, rate: u32) -> std::result::Result<Arc<SourceAudio>, String> {
    crate::file_access::check_read(p)?;
    files
        .entry(file_key(p))
        .or_insert_with(|| {
            let bytes = read_file(p).map_err(|_| p.display().to_string())?;
            decode_source(&bytes, p.extension().and_then(OsStr::to_str), rate).map_err(|err| format!("{}: {err}", p.display()))
        })
        .clone()
}

#[cfg(test)]
mod save_tests {
    use super::super::{AudioBuffer, ChannelFormat, Clip, Engine, FileFormat, Range, TrackKind, back_up, copy_new};
    use super::*;
    use serde_json::json;

    /// A new, empty scratch folder, removed again when the test ends, passed or not.
    struct Scratch(std::path::PathBuf);

    impl Scratch {
        fn new(tag: &str) -> Scratch {
            let dir = std::env::temp_dir().join(format!("soundcraft-{tag}-{}", std::process::id()));
            let _ = std::fs::remove_dir_all(&dir);
            std::fs::create_dir_all(&dir).unwrap();
            Scratch(dir)
        }
    }

    impl Drop for Scratch {
        fn drop(&mut self) {
            let _ = std::fs::remove_dir_all(&self.0);
        }
    }

    #[test]
    fn a_session_file_too_large_to_parse_is_refused_unread() {
        // #892: a session file is read whole and parsed; past the cap it is refused by its size.
        // The file's length is set, not written, so it takes no time or space to make.
        let dir = Scratch::new("huge-session");
        let path = dir.0.join("Huge.scraft");
        std::fs::File::create(&path).unwrap().set_len(crate::io::MAX_SESSION_BYTES + 1).unwrap();
        let mut e = crate::demo::demo_engine();
        let err = open_session(&mut e, &path).unwrap_err().to_string();
        assert_eq!(err, format!("{} is too large to open (over 256 MiB)", path.display()));
        assert_eq!(e.session().tracks.len(), crate::demo::demo_engine().session().tracks.len());
        let err = e.execute("file.import_session_data", &json!({"path": path.to_string_lossy()})).unwrap_err().to_string();
        assert!(err.contains("too large to open"), "{err}");
    }

    #[test]
    fn a_session_too_large_to_open_is_not_saved_and_leaves_nothing_behind() {
        // #892: what SoundCraft saves, it opens again. A refused save writes no audio and no
        // session; the limit is lowered for this test so a small session reaches it.
        let dir = Scratch::new("refused-save");
        let path = |p: &str| dir.0.join(p).to_string_lossy().into_owned();
        save_session(&mut with_take(0.5), &path("A/Song.scraft")).unwrap();
        let saved = std::fs::metadata(path("A/Song.scraft")).unwrap().len();
        let untouched = |sub: &str| assert!(!dir.0.join(sub).exists(), "{sub} was written");
        {
            let _limit = crate::io::SessionLimit::set(saved - 1);
            let mut e = with_take(0.5);
            let err = save_session(&mut e, &path("B/Song.scraft")).unwrap_err().to_string();
            assert_eq!(err, format!("{} is too large to save: over {} bytes, more than SoundCraft opens", path("B/Song.scraft"), saved - 1));
            assert!(e.is_dirty() && e.path.is_none());
            let err = e.execute("session.save_copy", &json!({"path": path("C/Song.scraft")})).unwrap_err().to_string();
            assert!(err.contains("too large to save"), "{err}");
            for sub in ["B", "C"] {
                untouched(sub);
            }
            // An open refuses the session saved before, now over the limit.
            let err = open_session(&mut Engine::default(), path("A/Song.scraft")).unwrap_err().to_string();
            assert!(err.contains("too large to open"), "{err}");
        }
        {
            // A template holds no audio or clips: a smaller limit refuses it.
            let _limit = crate::io::SessionLimit::set(100);
            std::fs::create_dir_all(dir.0.join("D")).unwrap();
            let err = with_take(0.5).execute("session.save_template", &json!({"path": path("D/Song.scraft")})).unwrap_err().to_string();
            assert!(err.contains("too large to save"), "{err}");
            untouched("D/Song.scraft");
        }
        // Checked before the audio file is named, against the longest name it can get: a
        // session at the limit plus that margin is saved, and is the same size as before.
        let _limit = crate::io::SessionLimit::set(saved + 5);
        save_session(&mut with_take(0.5), &path("B/Song.scraft")).unwrap();
        assert_eq!(std::fs::metadata(path("B/Song.scraft")).unwrap().len(), saved);
        assert_eq!(reopen(&path("B/Song.scraft")).session().sources.len(), 1);
    }

    #[test]
    fn a_saved_session_parses_as_it_did_through_a_tree() {
        // #892: parsing the text directly gives the document the `Value` round trip gave.
        let mut e = crate::demo::demo_engine();
        e.execute("mix.volume", &json!({"track": "Kick", "db": -7.0})).unwrap();
        let text = e.session().to_json().unwrap();
        let mut old: Session = serde_json::from_value(serde_json::from_str(&text).unwrap()).unwrap();
        old.sanitize();
        assert_eq!(Session::from_json(&text).unwrap(), old);
        let mut r = Engine::default();
        let dir = Scratch::new("reparse");
        let path = dir.0.join("Song.scraft").to_string_lossy().into_owned();
        save_session(&mut e, &path).unwrap();
        assert_eq!(open_session(&mut r, &path).unwrap(), Vec::<String>::new());
        assert_eq!(r.session().tracks, e.session().tracks);
    }

    #[test]
    fn autosave_copy_leaves_document_untouched_and_reuses_audio() {
        let mut e = crate::demo::demo_engine();
        e.execute("mix.volume", &serde_json::json!({"track": "Kick", "db": -7.0})).unwrap();
        let dir = std::env::temp_dir().join(format!("soundcraft-autosave-{}", std::process::id()));
        let path = dir.join("Midnight Groove.scraft");
        let p = path.to_string_lossy().into_owned();
        let n1 = save_copy(&e, &p).unwrap();
        let n2 = save_copy(&e, &p).unwrap();
        assert!(n1 >= 5);
        assert_eq!(n2, 0, "second autosave must not rewrite audio");
        assert!(e.is_dirty() && e.path.is_none());
        let mut r = Engine::default();
        open_session(&mut r, &p).unwrap();
        assert_eq!(r.session().track_by_name("Kick").unwrap().mixer.volume_db, -7.0);
        let _ = std::fs::remove_dir_all(&dir);
    }

    fn with_take(level: f32) -> Engine {
        let mut e = Engine::default();
        let s = e.session_mut();
        let t = s.add_track(TrackKind::Audio, ChannelFormat::Mono, None);
        let src = add_source(s, "Audio 1_02", AudioBuffer { sample_rate: 48_000, channels: vec![vec![level; 4_800]] }, None, FileFormat::Wav);
        let id = s.new_clip_id();
        crate::edit::place_clip(s, t, Clip::audio(id, "Audio 1_02", src, 0, 0, 4_800));
        e
    }

    fn reopen(path: &str) -> Engine {
        let mut r = Engine::default();
        assert_eq!(open_session(&mut r, path).unwrap(), Vec::<String>::new());
        r
    }

    #[test]
    fn saving_never_replaces_audio_of_another_session() {
        let dir = std::env::temp_dir().join(format!("soundcraft-no-replace-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let path = |p: &str| dir.join(p).to_string_lossy().into_owned();
        save_session(&mut with_take(0.5), &path("A/A.scraft")).unwrap();
        save_session(&mut with_take(-0.25), &path("A/A v2.scraft")).unwrap();
        save_session(&mut with_take(0.75), &path("B/B.scraft")).unwrap();
        save_session(&mut reopen(&path("B/B.scraft")), &path("A/B.scraft")).unwrap();
        let levels = ["A/A.scraft", "A/A v2.scraft", "B/B.scraft", "A/B.scraft"].map(|p| {
            let r = reopen(&path(p));
            r.session().pool.get(r.session().sources[0].id).unwrap().buffer.channels[0][0]
        });
        assert_eq!(levels, [0.5, -0.25, 0.75, 0.75]);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn consolidating_twice_keeps_both_renders() {
        let dir = std::env::temp_dir().join(format!("soundcraft-consolidate-twice-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let path = dir.join("Song.scraft").to_string_lossy().into_owned();
        let mut e = crate::demo::demo_engine();
        let kick = e.session().track_by_name("Kick").unwrap().id;
        let end = e.session().content_end();
        let render = |e: &Engine| soundcraft_mix::render_clips(e.session(), kick, Range::new(0, end));
        e.execute("edit.consolidate", &json!({"tracks": [kick.0], "start": 500_000, "end": 560_000})).unwrap();
        save_session(&mut e, &path).unwrap();
        e.execute("edit.consolidate", &json!({"tracks": [kick.0], "start": 1_400_000, "end": 1_500_000})).unwrap();
        save_session(&mut e, &path).unwrap();
        assert!(render(&reopen(&path)) == render(&e));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn saving_after_undo_reuses_the_saved_audio() {
        let dir = std::env::temp_dir().join(format!("soundcraft-undo-resave-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let path = dir.join("Song.scraft").to_string_lossy().into_owned();
        let mut e = with_take(0.5);
        e.execute("track.new", &json!({})).unwrap();
        assert_eq!(save_session(&mut e, &path).unwrap(), 1);
        e.execute("edit.undo", &json!({})).unwrap();
        assert_eq!(save_session(&mut e, &path).unwrap(), 0);
        assert_eq!(std::fs::read_dir(dir.join("Audio Files")).unwrap().count(), 1);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn saved_audio_is_trusted_only_in_the_folder_it_was_saved_in() {
        let dir = std::env::temp_dir().join(format!("soundcraft-own-folder-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let path = |p: &str| dir.join(p).to_string_lossy().into_owned();
        let level = |r: &Engine| r.session().pool.get(r.session().sources[0].id).unwrap().buffer.channels[0][0];
        save_session(&mut with_take(-0.25), &path("B/Other.scraft")).unwrap();
        let mut e = with_take(0.5);
        save_session(&mut e, &path("A/A.scraft")).unwrap();
        e.execute("track.new", &json!({})).unwrap();
        save_session(&mut e, &path("B/B.scraft")).unwrap();
        e.execute("edit.undo", &json!({})).unwrap();
        e.execute("session.save", &json!({})).unwrap();
        assert_eq!(level(&reopen(&path("B/B.scraft"))), 0.5);
        e.execute("session.save_copy", &json!({"path": path("A/Copy.scraft")})).unwrap();
        e.execute("session.save", &json!({})).unwrap();
        assert_eq!(level(&reopen(&path("B/B.scraft"))), 0.5);
        std::fs::remove_file(dir.join("A/Audio Files/Audio 1_02.wav")).unwrap();
        let mut missing = Engine::default();
        open_session(&mut missing, path("A/A.scraft")).unwrap();
        save_session(&mut missing, &path("B/Moved.scraft")).unwrap();
        let mut r = Engine::default();
        assert_eq!(
            open_session(&mut r, path("B/Moved.scraft")).unwrap(),
            vec![dir.join("A").join("Audio Files").join("Audio 1_02.wav").display().to_string()]
        );
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn saving_over_another_session_needs_replace() {
        let dir = std::env::temp_dir().join(format!("soundcraft-replace-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let path = dir.join("Song.scraft").to_string_lossy().into_owned();
        let mut first = with_take(0.5);
        first.execute("session.save_as", &json!({"path": path})).unwrap();
        first.execute("session.save", &json!({})).unwrap();
        first.execute("session.save_as", &json!({"path": dir.join("Song")})).unwrap();
        assert!(first.execute("session.save_template", &json!({"path": path})).is_err());
        let mut second = with_take(-0.25);
        let track = second.session().tracks[0].id.0;
        for id in ["session.save", "session.save_as", "session.save_copy", "session.save_template", "file.export_selected_tracks_as_session"] {
            let err = second.execute(id, &json!({"path": path, "tracks": [track]})).unwrap_err();
            assert!(err.to_string().contains("`replace: true`"), "{id}: {err}");
        }
        assert_eq!(std::fs::read_dir(dir.join("Audio Files")).unwrap().count(), 1);
        Engine::default().execute("session.save_as", &json!({"path": dir.join("New/New.scraft")})).unwrap();
        std::fs::copy(&path, dir.join("Song")).unwrap();
        let mut bare = Engine::default();
        open_session(&mut bare, dir.join("Song")).unwrap();
        bare.execute("session.save", &json!({})).unwrap();
        second.execute("session.save_as", &json!({"path": path, "replace": true})).unwrap();
        let r = reopen(&path);
        assert_eq!(r.session().pool.get(r.session().sources[0].id).unwrap().buffer.channels[0][0], -0.25);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn saving_keeps_the_last_ten_versions_as_backups() {
        let dir = std::env::temp_dir().join(format!("soundcraft-backups-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("Song.scraft");
        let mut e = Engine::default();
        let mut versions = Vec::new();
        for i in 0..12 {
            e.execute("track.new", &json!({"name": format!("T{i}")})).unwrap();
            save_session(&mut e, &path.to_string_lossy()).unwrap();
            save_session(&mut e, &path.to_string_lossy()).unwrap();
            versions.push(std::fs::read(&path).unwrap());
        }
        let backup = |n: usize| std::fs::read(dir.join(format!("Backups/Song backup {n}.scraft"))).ok();
        assert_eq!(std::fs::read_dir(dir.join("Backups")).unwrap().count(), 10);
        assert_eq!((backup(1), backup(2), backup(11)), (None, Some(versions[1].clone()), Some(versions[10].clone())));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn backup_never_overwrites_an_existing_entry_when_numbers_run_out() {
        let dir = std::env::temp_dir().join(format!("soundcraft-backups-full-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(dir.join("Backups")).unwrap();
        let path = dir.join("Song.scraft");
        std::fs::write(&path, b"session").unwrap();
        let last = dir.join(format!("Backups/Song backup {}.scraft", u32::MAX));
        std::fs::write(&last, b"sentinel").unwrap();
        back_up(&path);
        assert_eq!(std::fs::read(&last).unwrap(), b"sentinel");
        let dest = dir.join("Backups/Song backup 1.scraft");
        std::fs::write(&dest, b"taken").unwrap();
        assert!(copy_new(&path, &dest).is_err());
        assert_eq!(std::fs::read(&dest).unwrap(), b"taken");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[cfg(unix)]
    #[test]
    fn backup_never_writes_through_a_link_to_an_outside_file() {
        let dir = std::env::temp_dir().join(format!("soundcraft-backups-link-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(dir.join("Project/Backups")).unwrap();
        let outside = dir.join("outside.txt");
        std::fs::write(&outside, b"sentinel").unwrap();
        let path = dir.join("Project/Song.scraft");
        std::fs::write(&path, b"session").unwrap();
        std::os::unix::fs::symlink(&outside, dir.join(format!("Project/Backups/Song backup {}.scraft", u32::MAX))).unwrap();
        back_up(&path);
        let link = dir.join("Project/Backups/Song backup 1.scraft");
        std::os::unix::fs::symlink(&outside, &link).unwrap();
        assert!(copy_new(&path, &link).is_err());
        assert_eq!(std::fs::read(&outside).unwrap(), b"sentinel");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn save_gives_sources_that_share_a_path_their_own_files() {
        let mut s = Session::default();
        let loud = AudioBuffer { sample_rate: 48_000, channels: vec![vec![0.5; 64]] };
        let quiet = AudioBuffer { sample_rate: 48_000, channels: vec![vec![0.0; 64]] };
        add_source(&mut s, "tone", loud, Some("Audio Files/tone.wav"), FileFormat::Wav);
        add_source(&mut s, "tone", quiet, Some("Audio Files/tone.wav"), FileFormat::Wav);
        let mut e = Engine::new(s);
        let dir = std::env::temp_dir().join(format!("soundcraft-shared-path-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("Shared.scraft");
        save_session(&mut e, &path.to_string_lossy()).unwrap();
        let paths: Vec<_> = e.session().sources.iter().map(|src| src.path.clone()).collect();
        assert_eq!(paths.len(), 2);
        assert_ne!(paths[0], paths[1], "{paths:?}");
        let a = std::fs::read(dir.join(&paths[0])).unwrap();
        let b = std::fs::read(dir.join(&paths[1])).unwrap();
        assert_ne!(a, b);
        let _ = std::fs::remove_dir_all(&dir);
    }
}

#[cfg(test)]
mod open_tests {
    use super::super::{AudioBuffer, ChannelFormat, Clip, EncodeOptions, Engine, FileFormat, SourceId, TrackKind};
    use super::*;
    use serde_json::json;

    #[test]
    fn a_file_named_by_many_sources_is_decoded_once() {
        let dir = std::env::temp_dir().join(format!("soundcraft-shared-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        let audio = AudioBuffer { sample_rate: 48_000, channels: vec![vec![0.25; 480]] };
        std::fs::write(dir.join("k.wav"), craft_audio::encode(&audio, &EncodeOptions::default()).unwrap()).unwrap();
        let mut s = Session::default();
        for _ in 0..3 {
            add_source(&mut s, "k", audio.clone(), Some("k.wav"), FileFormat::Wav);
        }
        let path = dir.join("Song.scraft").to_string_lossy().into_owned();
        std::fs::write(&path, s.to_json().unwrap()).unwrap();
        let mut e = Engine::default();
        assert!(open_session(&mut e, &path).unwrap().is_empty());
        let (sources, pool) = (&e.session().sources, &e.session().pool);
        let first = pool.get(sources[0].id).unwrap();
        assert!(sources.iter().all(|src| pool.get(src.id).is_some_and(|a| Arc::ptr_eq(a, first))));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn sources_playing_one_file_share_it_when_saved() {
        let dir = std::env::temp_dir().join(format!("soundcraft-shared-save-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(dir.join("Audio Files")).unwrap();
        let audio = AudioBuffer { sample_rate: 48_000, channels: vec![vec![0.25; 480]] };
        std::fs::write(dir.join("Audio Files/k.wav"), craft_audio::encode(&audio, &EncodeOptions::default()).unwrap()).unwrap();
        let mut s = Session::default();
        for _ in 0..3 {
            add_source(&mut s, "k", audio.clone(), Some("Audio Files/k.wav"), FileFormat::Wav);
        }
        s.sources.iter_mut().for_each(|src| src.unsaved = false);
        let path = dir.join("Song.scraft").to_string_lossy().into_owned();
        std::fs::write(&path, s.to_json().unwrap()).unwrap();
        let mut e = Engine::default();
        open_session(&mut e, &path).unwrap();
        assert_eq!(save_session(&mut e, &path).unwrap(), 0);
        assert!(e.session().sources.iter().all(|src| src.path == "Audio Files/k.wav"));
        assert_eq!(save_copy(&e, &dir.join("copy/Song.scraft").to_string_lossy()).unwrap(), 1);
        assert_eq!(std::fs::read_dir(dir.join("copy/Audio Files")).unwrap().count(), 1);
        let _ = std::fs::remove_dir_all(&dir);
    }
    #[test]
    fn stored_paths_are_taken_from_the_session_folder() {
        let session = std::env::temp_dir().join("s").join("Song.scraft");
        assert_eq!(stored_path("Audio Files/k.wav", &session), Ok(session.with_file_name("Audio Files").join("k.wav")));
        #[cfg(windows)]
        assert_eq!(stored_path("Audio Files/take:2.wav", &session), Err("not opened: the path is not valid".into()));
        #[cfg(not(windows))]
        assert_eq!(stored_path(r"C:\Audio\k.wav", &session), Err("not opened: the path is not valid".into()));
    }

    #[test]
    fn stored_media_paths_are_followed_only_on_this_computer() {
        let dir = std::env::temp_dir().join(format!("soundcraft-stored-paths-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        let audio = AudioBuffer { sample_rate: 48_000, channels: vec![vec![0.25; 480]] };
        std::fs::write(dir.join("k.wav"), craft_audio::encode(&audio, &EncodeOptions::default()).unwrap()).unwrap();
        let mut saved = Session::default();
        let t = saved.add_track(TrackKind::Audio, ChannelFormat::Mono, None);
        let src = add_source(&mut saved, "k", audio, Some("../k.wav"), FileFormat::Wav);
        let id = saved.new_clip_id();
        crate::edit::place_clip(&mut saved, t, Clip::audio(id, "k", src, 0, 0, 480));
        // In a folder of its own, so a movie named `k.wav` is not relinked to a file beside it.
        std::fs::create_dir_all(dir.join("s")).unwrap();
        let path = dir.join("s").join("Song.scraft").to_string_lossy().into_owned();
        let mut stored = vec![r"\\192.0.2.1\share\x.wav".to_string(), "file://192.0.2.1/s/x.wav".to_string()];
        // Linux reads `//tmp/…` as the local `/tmp/…`, so only the path check keeps it from being read.
        if cfg!(unix) {
            stored.push(format!("/{}", dir.join("k.wav").display()));
        }
        let refused = |m: &str| m.contains("not opened: the path is on another computer");
        for p in stored {
            let mut s = saved.clone();
            s.sources[0].path.clone_from(&p);
            let id = SourceId(s.alloc());
            s.videos.push(soundcraft_model::VideoSource {
                id,
                name: "x".into(),
                path: p.clone(),
                width: 0,
                height: 0,
                frame_rate: 0.0,
                duration: 0.0,
                codec: String::new(),
                offline: None,
            });
            std::fs::write(&path, s.to_json().unwrap()).unwrap();
            let mut r = Engine::default();
            let missing = open_session(&mut r, &path).unwrap();
            assert_eq!(missing.iter().filter(|m| refused(m)).count(), 2, "{p}: {missing:?}");
            assert!(r.session().pool.get(r.session().sources[0].id).is_none(), "{p}");
            assert!(r.session().videos[0].offline.is_some(), "{p}");
            let mut into = Engine::default();
            let imported = into.execute("file.import_session_data", &json!({"path": path})).unwrap();
            assert!(imported["missing"].as_array().unwrap().iter().any(|m| m.as_str().is_some_and(refused)), "{p}: {imported}");
            assert!(into.session().pool.get(into.session().sources[0].id).is_none(), "{p}");
        }
        // A path relative to the session opens.
        std::fs::write(&path, saved.to_json().unwrap()).unwrap();
        let mut r = Engine::default();
        assert!(open_session(&mut r, &path).unwrap().is_empty());
        assert!(r.session().pool.get(r.session().sources[0].id).is_some());
        let _ = std::fs::remove_dir_all(&dir);
    }

    /// Every outcome of [`relink_videos`] for a movie: its file is there; it is gone but a file of
    /// the same name is next to the session or in its `Video Files` (relinked); it is gone with
    /// no copy (offline, path kept); its stored path is refused, with or without such a copy.
    #[test]
    fn each_movie_is_kept_relinked_or_offline() {
        let dir = std::env::temp_dir().join(format!("soundcraft-relink-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(dir.join("Movies")).unwrap();
        std::fs::create_dir_all(dir.join("Video Files")).unwrap();
        for f in ["Movies/here.mov", "near.mov", "Video Files/filed.mov", "remote_copy.mov"] {
            std::fs::write(dir.join(f), b"movie").unwrap();
        }
        let session = dir.join("Song.scraft");
        let mut s = Session::default();
        let stored = [
            "Movies/here.mov",
            "Old/near.mov",
            "Old/filed.mov",
            "Old/gone.mov",
            "file://192.0.2.1/s/remote.mov",
            "file://192.0.2.1/s/remote_copy.mov",
        ];
        for path in stored {
            let id = SourceId(s.alloc());
            s.videos.push(soundcraft_model::VideoSource {
                id,
                name: path.into(),
                path: path.into(),
                width: 0,
                height: 0,
                frame_rate: 0.0,
                duration: 0.0,
                codec: String::new(),
                offline: None,
            });
        }
        let missing = relink_videos(&mut s, &session);
        let got: Vec<(String, Option<String>)> = s.videos.iter().map(|v| (v.path.clone(), v.offline.clone())).collect();
        let at = |f: &str| dir.join(f).to_string_lossy().into_owned();
        assert_eq!(got[0], (stored_path("Movies/here.mov", &session).unwrap().to_string_lossy().into_owned(), None));
        assert_eq!(got[1], (at("near.mov"), None));
        assert_eq!(got[2], (at("Video Files/filed.mov"), None));
        assert_eq!(got[3], ("Old/gone.mov".into(), Some("file not found".into())));
        assert_eq!(got[4].0, stored[4]);
        assert!(got[4].1.as_deref().is_some_and(|why| why.starts_with("not opened:")), "{:?}", got[4]);
        assert_eq!(got[5], (at("remote_copy.mov"), None));
        assert_eq!(missing.len(), 2, "{missing:?}");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn a_missing_movie_is_offline_and_keeps_its_stored_path() {
        // The stored path is relative to the session and names no file. The movie is offline, so
        // the Video track never opens the stored string (the working directory would resolve
        // it), and the string is kept: saved into another folder, the session finds the movie
        // once it is back there under the same relative path.
        let dir = std::env::temp_dir().join(format!("soundcraft-missing-movie-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let (first, moved) = (dir.join("a"), dir.join("b"));
        std::fs::create_dir_all(&first).unwrap();
        std::fs::create_dir_all(moved.join("Movies")).unwrap();
        let mut s = Session::default();
        let id = SourceId(s.alloc());
        s.videos.push(soundcraft_model::VideoSource {
            id,
            name: "gone".into(),
            path: "Movies/gone.mov".into(),
            width: 0,
            height: 0,
            frame_rate: 0.0,
            duration: 0.0,
            codec: String::new(),
            offline: None,
        });
        let session = first.join("Song.scraft");
        std::fs::write(&session, s.to_json().unwrap()).unwrap();
        let mut e = Engine::default();
        let missing = open_session(&mut e, &session).unwrap();
        assert_eq!(missing, vec![format!("{} (video)", stored_path("Movies/gone.mov", &session).unwrap().display())]);
        let v = &e.session().videos[0];
        assert_eq!((v.path.as_str(), v.offline.as_deref()), ("Movies/gone.mov", Some("file not found")));
        // Saved next to the movie's new home, the session opens it.
        let session = moved.join("Song.scraft");
        save_session(&mut e, session.to_str().unwrap()).unwrap();
        std::fs::write(moved.join("Movies").join("gone.mov"), b"movie").unwrap();
        let mut r = Engine::default();
        assert!(open_session(&mut r, &session).unwrap().is_empty());
        let v = &r.session().videos[0];
        assert_eq!(v.path, stored_path("Movies/gone.mov", &session).unwrap().to_string_lossy());
        assert!(v.offline.is_none());
        let _ = std::fs::remove_dir_all(&dir);
    }
}

#[cfg(all(test, unix))]
mod pipe_tests {
    use super::super::{AudioBuffer, FileFormat};
    use super::*;
    use serde_json::json;

    #[test]
    fn a_pipe_named_as_media_is_refused_not_waited_on() {
        let dir = std::env::temp_dir().join(format!("soundcraft-pipe-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        let fifo = dir.join("pipe.wav");
        assert!(std::process::Command::new("mkfifo").arg(&fifo).status().unwrap().success());
        let mut s = Session::default();
        let audio = AudioBuffer { sample_rate: 48_000, channels: vec![vec![0.0; 10]] };
        add_source(&mut s, "pipe", audio, Some(&fifo.to_string_lossy()), FileFormat::Wav);
        let path = dir.join("Song.scraft").to_string_lossy().into_owned();
        std::fs::write(&path, s.to_json().unwrap()).unwrap();
        let (tx, rx) = std::sync::mpsc::channel();
        let pipe = fifo.to_string_lossy().into_owned();
        std::thread::spawn(move || {
            let mut e = Engine::default();
            let imported = e.execute("file.import_audio", &json!({"path": pipe})).is_ok();
            let _ = tx.send((imported, open_session(&mut e, &path).map_err(|err| err.to_string())));
        });
        let (imported, opened) = rx.recv_timeout(std::time::Duration::from_secs(10)).unwrap();
        assert!(!imported);
        assert_eq!(opened.unwrap(), [fifo.display().to_string()]);
        let _ = std::fs::remove_dir_all(&dir);
    }
}
